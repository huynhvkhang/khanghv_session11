let numbers = [1,2,3,4,4,6,6,6,8,9];
let search = parseInt(prompt("Nhập vào một số tài nguyên để thống kê"));
let numbers2 =0;
for(const element of numbers){
    if (element ==search) {
        numbers2++
    }
}
console.log("Số",search,"xuât hiện", numbers, "lần trong mảng");