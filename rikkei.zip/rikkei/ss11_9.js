let numbers = [6, 1, 4, -3,4,5, 9, -10, 5];
let exit = false;
for (let index = 0; index < numbers.length; index++) {
    if (numbers[index] == 1) {
        exit = true;
        break;
    }
}
if (!exit) {
    console.log("Số nguyên dương nhỏ nhất không có trong mảng là: 1");
} else {
    numbers.sort((a, b) => a - b);
    for (let i = 0; i < numbers.length; i++) {
        if (numbers[i] > 0 && numbers[i] + 1 != numbers[i + 1]) {
            console.log("Số nguyên dương nhỏ nhất không có trong mảng là:", numbers[i] + 1);
            break;
        }
    }
}