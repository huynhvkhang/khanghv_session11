let numbers = [,1,2,4,3,2,5,6,7,2,3,4];
let input = +prompt("Nhập vào số nguyên bất kỳ");
let indexStart, indexEnd;
for (let i = 0; i < numbers.length; i++) {
    if (numbers[i] == inputValue) {
        indexStart = i;
        indexEnd = i;
        break;
    } else {
        let sum = numbers[i];
        let isExit = false;
        for (let j = i + 1; j < numbers.length; j++) {
            sum += numbers[j];
            if (sum == inputValue) {
                indexStart = i;
                indexEnd = j;
                isExit = true;
                break;
            } else if (sum > inputValue) {
                break;
            }
        }
        if (isExit) {
            break;
        }
    }
}
console.log("Mảng con đầu tiên có tổng bằng", inputValue, "là");
for (let i = indexStart; i <= indexEnd; i++) {
    console.log(numbers[i]);
}