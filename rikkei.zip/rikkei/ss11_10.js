let firstNumbers = [1, 2, 3, 4, 5,];
let endNumbers = [-3, -1, 0, 1, 5];
let thirdNumbers = [1, 5, 6, 7];
console.log("Các phần tử có ở trong cả 3 mảng là:");
for (const element1 of firstNumbers) {
    let isExistOf2 = false;
    for (const element2 of endNumbers) {
        if (element1 == element2) {
            isExistOf2 = true;
            break;
        }
    }
    if (isExistOf2) {
        let isExistOf3 = false;
        for (const element3 of thirdNumbers) {
            if (element1 == element3) {
                isExistOf3 = true;
                break;
            }
        }
        if (isExistOf3) {
            console.log(element1);
        }
    }
}