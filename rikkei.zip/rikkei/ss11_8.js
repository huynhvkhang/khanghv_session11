let numbers = [1, 3, 5, 5, 4, 3, 5, 6,7, 5, 2];
let numberDuplicate = [];
for (let i = 0; i < numbers.length; i++) {
    for (let j = i + 1; j < numbers.length; j++) {
        if (numbers[i] == numbers[j]) {
            let isExistDuplicate = false;
            for (let k = 0; k < numberDuplicate.length; k++) {
                if (numbers[i] == numberDuplicate[k]) {
                    isExistDuplicate = true;
                    break;
                }
            }
            if (!isExistDuplicate) {
                numberDuplicate.push(numbers[i]);
            }
            break;
        }
    }
}
console.log("Các phần tử xuất hiện 2 lần trở lên trong mảng:", numberDuplicate);