let long =+prompy("Nhập số phần tử của mảng");
let numbers =[];
for (let index=0;index<long;index++) {
    numbers.push(+("Nhập vào phần tử thứ" + (index+1)));
}
for (let i=0;i<numbers.length -1;i++) {
    for (let j=i+1;j<numbers.length;j++){
        if(numbers[i]>numbers[j]) {
            let temp = numbers[i];
            numbers[i] = numbers[j];
            numbers[j] = temp;
        }
    }
}
console.log("Mảng sau khi sắp xếp:", numbers);