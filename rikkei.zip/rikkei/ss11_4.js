let firsnumbers = parseInt(prompt("Nhập số nguyên thứ nhất"));
let endnumbers = parseInt(prompt("Nhập số nguyên thứ hai"));
let numbers =[];
for (let i=1; i<= firsnumbers;i++){
    if(i % endnumbers == 0) {
        numbers.push(i)
    }
}
for (let j=1; j<= firsnumbers;j++){
    if(j % endnumbers == 0) {
        numbers.push(j)
    }
}
console.log("Các phần tử chia hết cho" , firsnumbers, "và", endnumbers, "là");
for (const element of numbers) {
    console.log(element);
}
