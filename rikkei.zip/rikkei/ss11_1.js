let numbers =[4,"Nguyễn Văn A ", "Nguyễn Văn B",3,5,9];
let exit =false;
console.log("Các phần tử là số nguyên trong mảng là: ");
for (const element of numbers) {
    if (parseInt(element) === element){
        exit=true;
        console.log(element);
    }  
}
if (exit){
    console.log("Trong mang không tồn tại số nguyên");
}