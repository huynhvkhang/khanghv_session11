let numbers =[1,3,5,7,3,3,-5,1,6,1,"Nguyễn Văn A"]
let search = prompt("Nhập giá trị cần tìm");
console.log("Chỉ số các phần tử tìm thấy trong mảng: ");
let exit = false;
for (let i=0;i<numbers.length;i++) {
    if (numbers[i] ==search){
        console.log(i);
        exit=true;
    }
}
if (!exit){
    console.log("Phần tử không tồn tại");
}